lib:
{
    moduleLoader = import ./module-loader.nix;
}