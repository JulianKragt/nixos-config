{ ... }:
{
  programs.nushell.enable = true;
}