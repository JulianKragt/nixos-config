{ config, lib, pkgs, options, modules, attrs, outputs, inputs, ... }:

let
  loader = lib.custom.moduleLoader {
    inherit lib pkgs config options modules attrs outputs inputs;
    moduleDir = ./features;
    group = "myHomeManager";
    configPath = config.myHomeManager;
  };
in
{
  options = loader.options;
  imports = loader.modules;
}