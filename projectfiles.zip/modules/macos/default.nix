{ config, lib, pkgs, options, modules, attrs, outputs, inputs, ... }:

let
  loader = lib.custom.moduleLoader {
    inherit lib pkgs config options modules attrs outputs inputs;
    moduleDir = ./features;
    group = "myMacOS";
    configPath = config.myMacOS;
  };
in
{
  options = loader.options;
  imports = loader.modules;

  # Any other config here...
  config.nix.settings.experimental-features = ["nix-command" "flakes" "pipe-operators"];
}
