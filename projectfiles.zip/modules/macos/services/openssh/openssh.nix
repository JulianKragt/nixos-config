{ ... }:
{
  services.openssh.enable = true;
}
