{
  ...
}:
{
  myNixOS.hyprland.enable = true;
}
